import React from "react";

export default function Carrito() {
  return <div>Carrito</div>;
}
